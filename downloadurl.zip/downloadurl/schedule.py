import threading
import Queue
import datetime
import generateallurl
import opt
import time
import sys
import kick

import downloadurlauto
def __init__(self, queue):
    threading.Thread.__init__(self)
    self.queue = queue
print 'initiating collecting data'
category_urls = open ('category2.text','r').readline()
if category != '':

    try:




         #downloadurlauto.downloadforurl(i)
    except BaseException as e:
        print(str(e))
        break
    else:
        pass
    print 'project %d has succesful porcess and do next' % i
    time.sleep(100)
    #print '%d have succesful porcess and do next' % i
