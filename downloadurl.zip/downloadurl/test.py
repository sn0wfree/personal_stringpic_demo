
a=[]
q=0
for i in range(0,54):#category
    for j in range(0, 200):
        for k in range(0, 4):
            #pledged max 4
            for l in range(0,5):
                #goal max4
                for m in range(0,3):
                    #max3
                    a.append(q)
                    q +=1
