from distutils.core import setup
import py2exe


setup(windows=['plan2.3.1copy.py'])
